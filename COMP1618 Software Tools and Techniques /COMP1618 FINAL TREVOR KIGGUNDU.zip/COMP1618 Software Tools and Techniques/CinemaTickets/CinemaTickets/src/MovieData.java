// List of imports required for the programe

// This class is to feed data about Movies and Tickets to the main program
// Initiate the class MovieData 
public class MovieData {
  
  // The string constructor is private to this class and should provide an output -- name & genres of movie
  private static String listHeader() {
    String output;
    output = "Movie Name                                   Genre\n";
    output += "== ===================================    ===================\n";
    return output;
  }
  // list the output titles of the string constructor as  ....

  public static String listAll() {
    String output = listHeader();

    output += "01 Kubo and The Two Strings               Fantasy/Family \n";
    output += "02 Finding Dory                           Comedy/Adventures \n";
    output += "03 The Secret Life of Pets                Comedy/Family \n";
    output += "04 In Time                                SciFi/Action \n";

    return output;
  }

  static String listGenres(String label) {
    String output = listHeader();
    return output;
  }

  // Movie details  
  static String getMovie(String id) {
    //the whole Movie details
    return null;
  }

  public static String getName(String id) {
    //Movie name
    return null;
  }

  public static void purchaseSlot(String id, int priority) {

  }

  public static void close() {

  }
}
